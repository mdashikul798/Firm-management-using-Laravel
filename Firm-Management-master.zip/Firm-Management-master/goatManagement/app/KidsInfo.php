<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KidsInfo extends Model
{
    //
}
