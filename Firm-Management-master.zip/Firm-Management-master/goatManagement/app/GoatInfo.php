<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GoatInfo extends Model
{
    //
}
